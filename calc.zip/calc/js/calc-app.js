(function(){//IEF = iffy = immediate 
    console.log("hi Elakkiya!");
    App = function(){
    }
    App.operator = "";
    App.calculated = 0;
    App.lastValue = 0;
    App.getInput= function(_input){
        console.log(typeof parseInt(_input));
        if(typeof _input == "number" && typeof parseInt(_input)!=NaN) {
            console.log(parseInt(_input))
            document.getElementById("disp-val").value +=_input;
            App.calculated = parseInt(document.getElementById("disp-val").value);
        }
        if(typeof _input == "string"){
            if(_input=="+" || _input=="-" || _input=="*" || _input=="/"){
                this.operator = _input;
                this.lastValue = parseInt(document.getElementById("disp-val").value);
                document.getElementById("disp-val").value = "";
            }
            if(_input.toLowerCase()=="clear"){
                this.operator = "";
                this.calculated = 0;
                this.lastValue = 0;
                document.getElementById("disp-val").value= "";
            }
            if(_input=="="){
                
                //this.calculated = this.lastValue;
                console.log(this.operator,this.calculated,this.lastValue);
                switch(this.operator){
                    case "+":
                    {
                        this.calculated = (this.calculated + this.lastValue);
                        break;
                    }
                    case "-":
                    {
                        this.calculated = (this.calculated - this.lastValue);
                        break;
                    }
                    case "*":
                    {
                        this.calculated = (this.calculated * this.lastValue);
                        break;
                    }
                    case "/":
                    {
                        
                        this.calculated = (this.lastValue / this.calculated);
                        break;
                    }
                }
                document.getElementById("disp-val").value = this.calculated;
            }
        }
    }
            

    return new App;
})();